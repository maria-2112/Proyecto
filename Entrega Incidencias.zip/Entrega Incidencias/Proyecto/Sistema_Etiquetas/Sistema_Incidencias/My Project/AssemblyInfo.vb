﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' La información general sobre un ensamblado se controla mediante el siguiente 
' conjunto de atributos. Cambie estos atributos para modificar la información
' asociada con un ensamblado.

' Revisar los valores de los atributos del ensamblado

<Assembly: AssemblyTitle("Sistema_Incidencias")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("Hewlett-Packard")>
<Assembly: AssemblyProduct("Sistema_Incidencias")>
<Assembly: AssemblyCopyright("Copyright © Hewlett-Packard 2016")>
<Assembly: AssemblyTrademark("")>

' La información de versión de un ensamblado consta de los cuatro valores siguientes:
'
'      Versión principal
'      Versión secundaria 
'      Número de compilación
'      Revisión
'
' Puede especificar todos los valores o establecer como predeterminados los números de compilación y de revisión 
' mediante el carácter '*', como se muestra a continuación:
' <Ensamblado: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
<Assembly: ComVisible(False)>