﻿Public Class DEstado
    Private _idEstado As Integer
    Private _descripcion As String

    Public Property IdEstado() As String
        Get
            Return _idEstado
        End Get
        Set(ByVal value As String)
            _idEstado = value
        End Set
    End Property
    Public Property Descripcion() As String
        Get
            Return _descripcion
        End Get
        Set(ByVal value As String)
            _descripcion = value
        End Set
    End Property

    Public Sub New()

    End Sub
    Public Sub New(ByVal id As Integer, ByVal nom As String, ByVal ho As Integer)
        IdEstado = id
        Descripcion = nom
    End Sub
End Class
