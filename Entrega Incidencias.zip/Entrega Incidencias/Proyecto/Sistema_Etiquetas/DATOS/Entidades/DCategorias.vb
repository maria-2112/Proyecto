﻿Public Class DCategorias
    Private _idCategorias As Integer
    Private _horas As Integer
    Private _descripcion As String

    Public Property IdCategoria() As String
        Get
            Return _idCategorias
        End Get
        Set(ByVal value As String)
            _idCategorias = value
        End Set
    End Property
    Public Property Descripcion() As String
        Get
            Return _descripcion
        End Get
        Set(ByVal value As String)
            _descripcion = value
        End Set
    End Property

    Public Property Horas() As String
        Get
            Return _horas
        End Get
        Set(ByVal value As String)
            _horas = value
        End Set
    End Property

    Public Sub New()

    End Sub
    Public Sub New(ByVal id As Integer, ByVal nom As String, ByVal ho As Integer)
        IdCategoria = id
        Descripcion = nom
        Horas = ho

    End Sub
End Class
