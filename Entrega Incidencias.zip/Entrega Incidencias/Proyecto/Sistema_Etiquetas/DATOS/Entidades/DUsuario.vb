﻿Public Class DUsuario
    Private _idUsuario As Integer
    Private _idRol As Integer
    Private _nombre As String
    Private _apellidos As String
    Private _cedula As String
    Private _telefono As String
    Private _direccion As String
    Private _correo As String
    Private _usuario As String
    Private _pass As String
    Private _fecha_Nac As String
    Public Property Fecha_Nac() As String
        Get
            Return _fecha_Nac
        End Get
        Set(ByVal value As String)
            _fecha_Nac = value
        End Set
    End Property

    Public Property IdRol() As String
        Get
            Return _idRol
        End Get
        Set(ByVal value As String)
            _idRol = value
        End Set
    End Property

    Public Property CodUsuario() As Integer
        Get
            Return _idUsuario
        End Get
        Set(ByVal value As Integer)
            _idUsuario = value
        End Set
    End Property
    Public Property Apellido() As String
        Get
            Return _apellidos
        End Get
        Set(ByVal value As String)
            _apellidos = value
        End Set
    End Property


    Public Property Nombre() As String
        Get
            Return _nombre
        End Get
        Set(ByVal value As String)
            _nombre = value
        End Set
    End Property

    Public Property Pass() As String
        Get
            Return _pass
        End Get
        Set(ByVal value As String)
            _pass = value
        End Set
    End Property
    Public Property Usuario() As String
        Get
            Return _usuario
        End Get
        Set(ByVal value As String)
            _usuario = value
        End Set
    End Property

    Public Property Cedula() As String
        Get
            Return _cedula
        End Get
        Set(ByVal value As String)
            _cedula = value
        End Set
    End Property

    Public Property Direccion() As String
        Get
            Return _direccion
        End Get
        Set(ByVal value As String)
            _direccion = value
        End Set
    End Property
    Public Property Correo() As String
        Get
            Return _correo
        End Get
        Set(ByVal value As String)
            _correo = value
        End Set
    End Property
    Public Property Telefono() As String
        Get
            Return _telefono
        End Get
        Set(ByVal value As String)
            _telefono = value
        End Set
    End Property

    Public Sub New()

    End Sub

    Public Sub New(ByVal idu As Integer, ByVal idr As Integer, ByVal nom As String, ByVal ape As String, ByVal ced As String, ByVal tel As String, ByVal dic As String, ByVal cor As String, ByVal user As String, ByVal pas As String)
        IdRol = idr
        CodUsuario = idu
        Nombre = nom
        Apellido = ape
        Cedula = ced
        Telefono = tel
        Direccion = dic
        Correo = cor
        Usuario = user
        Pass = pas

    End Sub
End Class
