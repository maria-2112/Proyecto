﻿Public Class DRoles
    Private _idRol As Integer
    Private _descripcion As String

    Public Property IdRol() As String
        Get
            Return _idRol
        End Get
        Set(ByVal value As String)
            _idRol = value
        End Set
    End Property
    Public Property Descripcion() As String
        Get
            Return _descripcion
        End Get
        Set(ByVal value As String)
            _descripcion = value
        End Set
    End Property

    Public Sub New()

    End Sub
    Public Sub New(ByVal id As Integer, ByVal nom As String)
        IdRol = id
        Descripcion = nom

    End Sub
End Class
