﻿Public Class DIncidencias
    Private _idIncidencias As String
    Private _idUsuario As Integer
    Private _fecha_Creaci As String
    Private _idCategorias As Integer
    Private _fecha_Est As String
    Private _fecha_Asigna As String
    Private _fecha_Resul As String
    Private _estado As Integer
    Private _cancelado As Boolean
    Private _cedula As String
    Private _horas As String

    Public Property Horas() As Integer
        Get
            Return _horas
        End Get
        Set(ByVal value As Integer)
            _horas = value
        End Set
    End Property


    Public Property Cedula() As String
        Get
            Return _cedula
        End Get
        Set(ByVal value As String)
            _cedula = value
        End Set
    End Property

    Public Property CodIncidencia() As String
        Get
            Return _idIncidencias
        End Get
        Set(ByVal value As String)
            _idIncidencias = value
        End Set
    End Property
    Public Property CodUsuario() As Integer
        Get
            Return _idUsuario
        End Get
        Set(ByVal value As Integer)
            _idUsuario = value
        End Set
    End Property
    Public Property Fecha_Creacion() As String
        Get
            Return _fecha_Creaci
        End Get
        Set(ByVal value As String)
            _fecha_Creaci = value
        End Set
    End Property
    Public Property IdCategorias() As String
        Get
            Return _idCategorias
        End Get
        Set(ByVal value As String)
            _idCategorias = value
        End Set
    End Property

    Public Property Fecha_Est() As String
        Get
            Return _fecha_Est
        End Get
        Set(ByVal value As String)
            _fecha_Est = value
        End Set
    End Property
    Public Property Fecha_Asigna() As String
        Get
            Return _fecha_Asigna
        End Get
        Set(ByVal value As String)
            _fecha_Asigna = value
        End Set
    End Property
    Public Property Fecha_Result() As String
        Get
            Return _fecha_Resul
        End Get
        Set(ByVal value As String)
            _fecha_Resul = value
        End Set
    End Property

    Public Property Estado() As Integer
        Get
            Return _estado
        End Get
        Set(ByVal value As Integer)
            _estado = value
        End Set
    End Property

    Public Property Cancelado() As Boolean
        Get
            Return _cancelado
        End Get
        Set(ByVal value As Boolean)
            _cancelado = value
        End Set
    End Property

    Public Sub New()

    End Sub
    Public Sub New(ByVal idi As Integer, ByVal idu As Integer, ByVal idc As Integer, ByVal fc As String, ByVal fe As String, ByVal fa As String, ByVal fr As String, ByVal est As Boolean, ByVal canc As Boolean)
        CodIncidencia = idi
        CodUsuario = idu
        Fecha_Creacion = fc
        IdCategorias = idc
        Fecha_Est = fe
        Fecha_Asigna = fa
        Fecha_Result = fr
        Estado = est
        Cancelado = canc

    End Sub

End Class

