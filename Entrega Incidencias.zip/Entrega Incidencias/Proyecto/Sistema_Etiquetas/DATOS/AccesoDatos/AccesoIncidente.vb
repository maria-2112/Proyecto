﻿Imports System.Data
Imports System.Data.SqlClient
Public Class AccesoIncidente
    Inherits Configuracion
    Shared cmd As New SqlCommand
    Public Shared Function ObtenerIncidentes() As DataTable

        Try
            conectado()
            cmd = New SqlCommand("mostrar_incidentes")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function

    Public Shared Function ObtenerIncidentesId(pid As Integer) As DataTable

        Try
            conectado()
            cmd = New SqlCommand("mostrar_incidentes_Id")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn
            cmd.Parameters.AddWithValue("@ID_INCIDENCIAS", pid)

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function

    Public Shared Function ObtenerIncidentesUsuario(pidUsuario As Integer) As DataTable

        Try
            conectado()
            cmd = New SqlCommand("mostrar_incidente_usuario")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn
            cmd.Parameters.AddWithValue("@ID_USUARIO", pidUsuario)

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function


    Public Shared Sub InsertarIncidencia(pincidente As DIncidencias)
        Try
            conectado()
            cmd = New SqlCommand("insertar_incidente")
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = cnn

            cmd.Parameters.AddWithValue("@ID_USUARIO", pincidente.CodUsuario)
            cmd.Parameters.AddWithValue("@FECHA_CREACION", pincidente.Fecha_Creacion)
            cmd.Parameters.AddWithValue("@ID_CATEGORIAS", pincidente.IdCategorias)
            cmd.Parameters.AddWithValue("@FECHA_ESTN", pincidente.Fecha_Est)
            cmd.Parameters.AddWithValue("@FECHA_ASIGNA", pincidente.Fecha_Asigna)
            cmd.Parameters.AddWithValue("@FECHA_RESULT", pincidente.Fecha_Result)
            cmd.Parameters.AddWithValue("@ID_ESTADO_INC", pincidente.Estado)
            cmd.Parameters.AddWithValue("@CANCELACION", pincidente.Cancelado)

            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)

        Finally
            desconectado()
        End Try
    End Sub

    Public Shared Sub EditarIncidencia(pincidente As DIncidencias)
        Try
            conectado()
            cmd = New SqlCommand("editar_incidente")
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = cnn

            cmd.Parameters.AddWithValue("@ID_INCIDENCIA", pincidente.CodIncidencia)
            cmd.Parameters.AddWithValue("@ID_USUARIO", pincidente.CodUsuario)
            cmd.Parameters.AddWithValue("@FECHA_CREACION", pincidente.Fecha_Creacion)
            cmd.Parameters.AddWithValue("@ID_CATEGORIAS", pincidente.IdCategorias)
            cmd.Parameters.AddWithValue("@FECHA_ESTN", pincidente.Fecha_Est)
            cmd.Parameters.AddWithValue("@FECHA_ASIGNA", pincidente.Fecha_Asigna)
            cmd.Parameters.AddWithValue("@FECHA_RESULT", pincidente.Fecha_Result)
            cmd.Parameters.AddWithValue("@HORAS", pincidente.Horas)
            cmd.Parameters.AddWithValue("@ID_ESTADO_INC", pincidente.Estado)
            cmd.Parameters.AddWithValue("@CANCELACION", pincidente.Cancelado)

            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)

        Finally
            desconectado()
        End Try
    End Sub
    Public Shared Sub CancelarIncidencia(pidIncidencia As Integer)
        Try
            conectado()
            cmd = New SqlCommand("cancelar_incidencia")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn
            cmd.Parameters.AddWithValue("@ID_INCIDENCIA", pidIncidencia)

            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)

        Finally
            desconectado()
        End Try
    End Sub

    Public Shared Function ObtenerConsultaIncidencias() As DataTable

        Try
            conectado()
            cmd = New SqlCommand("mostrar_ConsultaIncidencias")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function
End Class
