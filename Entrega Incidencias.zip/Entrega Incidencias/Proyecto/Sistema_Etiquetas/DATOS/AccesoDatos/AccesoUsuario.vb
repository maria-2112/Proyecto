﻿Imports System.Data
Imports System.Data.SqlClient

Public Class AccesoUsuario
    Inherits Configuracion
    Shared cmd As New SqlCommand
    Public Shared Function ObtenerUsuario(pusuario As DUsuario) As DataTable

        Try
            conectado()
            cmd = New SqlCommand("mostrar_usuario")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn
            cmd.Parameters.AddWithValue("@USUARIO", pusuario.Usuario)
            cmd.Parameters.AddWithValue("@PASS", pusuario.Pass)

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function

    Public Shared Function ObtenerUsuarioCedula(pusuarioCed As String) As DataTable

        Try
            conectado()
            cmd = New SqlCommand("mostrar_usuario_cedula")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn
            cmd.Parameters.AddWithValue("@CEDULA", pusuarioCed)

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function

    Public Shared Function ObtenerUsuarioCodUsuario(pusuarioCode As Integer) As DataTable

        Try
            conectado()
            cmd = New SqlCommand("mostrar_usuario_codUsuario")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn
            cmd.Parameters.AddWithValue("@COD_USUARIO", pusuarioCode)

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function

    Public Shared Sub InsertarUsuario(pusuario As DUsuario)
        Try
            conectado()
            cmd = New SqlCommand("insertar_usuario")
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = cnn

            cmd.Parameters.AddWithValue("@NOMBRE", pusuario.Nombre)
            cmd.Parameters.AddWithValue("@APELLIDOS", pusuario.Apellido)
            cmd.Parameters.AddWithValue("@DIRECCION", pusuario.Direccion)
            cmd.Parameters.AddWithValue("@TELEFONO", pusuario.Telefono)
            cmd.Parameters.AddWithValue("@CEDULA", pusuario.Cedula)
            cmd.Parameters.AddWithValue("@CORREO", pusuario.Correo)
            cmd.Parameters.AddWithValue("@USUARIO", pusuario.Usuario)
            cmd.Parameters.AddWithValue("@PASS", pusuario.Pass)
            cmd.Parameters.AddWithValue("@ID_ROLES", pusuario.IdRol)

            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)

        Finally
            desconectado()
        End Try
    End Sub
    Public Shared Sub EditarUsuario(pusuario As DUsuario)
        Try
            conectado()
            cmd = New SqlCommand("editar_usuario")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn
            cmd.Parameters.AddWithValue("@ID_USUARIO", pusuario.CodUsuario)
            cmd.Parameters.AddWithValue("@NOMBRE", pusuario.Nombre)
            cmd.Parameters.AddWithValue("@APELLIDOS", pusuario.Apellido)
            cmd.Parameters.AddWithValue("@DIRECCION", pusuario.Direccion)
            cmd.Parameters.AddWithValue("@TELEFONO", pusuario.Telefono)
            cmd.Parameters.AddWithValue("@CEDULA", pusuario.Cedula)
            cmd.Parameters.AddWithValue("@CORREO", pusuario.Correo)
            cmd.Parameters.AddWithValue("@USUARIO", pusuario.Usuario)
            cmd.Parameters.AddWithValue("@PASS", pusuario.Pass)
            cmd.Parameters.AddWithValue("@ID_ROLES", pusuario.IdRol)

            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)

        Finally
            desconectado()
        End Try
    End Sub


    'TERMINAR
    Public Shared Sub EliminarUsuario(ByVal obj As DUsuario)
        Try
            conectado()
            cmd = New SqlCommand("eliminar_usuario")
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = cnn

            cmd.Parameters.Add("@ID_USUARIO", SqlDbType.Int).Value = obj.CodUsuario
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            desconectado()

        End Try
    End Sub

    Public Shared Function ObtenerUsuarios() As DataTable

        Try
            conectado()
            cmd = New SqlCommand("mostrar_usuarios")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function
End Class
