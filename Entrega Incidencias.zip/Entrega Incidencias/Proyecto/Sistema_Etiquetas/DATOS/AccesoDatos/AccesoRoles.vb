﻿Imports System.Data
Imports System.Data.SqlClient

Public Class AccesoRoles
    Inherits Configuracion
    Shared cmd As New SqlCommand
    Public Shared Function ObtenerRoles() As DataTable

        Try
            conectado()
            cmd = New SqlCommand("mostrar_roles")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function

    Public Shared Function ObtenerRolId(pid As Integer) As DataTable

        Try
            conectado()
            cmd = New SqlCommand("mostrar_categoria_Id")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn
            cmd.Parameters.AddWithValue("@Id_Rol", pid)

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function

    Public Shared Sub InsertarRol(ByVal obj As DRoles)
        Try
            conectado()
            cmd = New SqlCommand("insertar_role")
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = cnn

            cmd.Parameters.AddWithValue("@nombre_rol", obj.Descripcion)
            cmd.ExecuteNonQuery()


        Catch ex As Exception
            MsgBox(ex.Message)

        Finally
            desconectado()
        End Try
    End Sub
    Public Shared Sub EliminarRole(ByVal cat As DRoles)
        Try
            conectado()
            cmd = New SqlCommand("eliminar_role")
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = cnn

            cmd.Parameters.Add("eliminar_role", SqlDbType.Int).Value = cat.IdRol
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            desconectado()

        End Try
    End Sub

End Class
