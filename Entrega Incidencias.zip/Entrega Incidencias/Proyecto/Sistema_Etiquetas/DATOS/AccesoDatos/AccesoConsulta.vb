﻿Imports System.Data
Imports System.Data.SqlClient
Public Class AccesoConsulta
    Inherits Configuracion

    Shared cmd As New SqlCommand


    Public Shared Function ObtenerConsulta() As DataTable

        Try
            conectado()
            cmd = New SqlCommand("mostrar_ConsultaIncidencias")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function
    Public Shared Function ObtenerConsultaFecha(ByVal fec As String, ByVal fec2 As String) As DataTable

        Try
            conectado()
            cmd = New SqlCommand("mostrar_ConsultaIncidenciasFecha")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn


            cmd.Parameters.AddWithValue("@inicio", Convert.ToDateTime(fec))
            cmd.Parameters.AddWithValue("@final", Convert.ToDateTime(fec2))

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function

    Public Shared Function ObtenerConsultaFechaAsigna(ByVal fec As String, ByVal fec2 As String) As DataTable

        Try
            conectado()
            cmd = New SqlCommand("mostrar_ConsultaIncidenciasFechaAsigna")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn


            cmd.Parameters.AddWithValue("@inicio", Convert.ToDateTime(fec))
            cmd.Parameters.AddWithValue("@final", Convert.ToDateTime(fec2))

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function

    Public Shared Function ObtenerConsultaFechaResult(ByVal fec As String, ByVal fec2 As String) As DataTable

        Try
            conectado()
            cmd = New SqlCommand("mostrar_ConsultaIncidenciasFechaResult")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn


            cmd.Parameters.AddWithValue("@inicio", Convert.ToDateTime(fec))
            cmd.Parameters.AddWithValue("@final", Convert.ToDateTime(fec2))

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function

    Public Shared Function ObtenerConsultaEstado(ByVal obj As String) As DataTable

        Try
            conectado()
            cmd = New SqlCommand("mostrar_ConsultaEstados")
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Connection = cnn


            cmd.Parameters.AddWithValue("@inicio", Convert.ToString(obj))


            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function

    Public Shared Function ConsultarIncidenciasResueltas(pidEstado As Integer, pidCategoria As Integer) As DataTable

        Try
            conectado()
            cmd = New SqlCommand("consultarIncidenciasResueltas")
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = cnn

            cmd.Parameters.AddWithValue("@ID_ESTADO_INC", pidEstado)
            cmd.Parameters.AddWithValue("@ID_CATEGORIAS", pidCategoria)

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function

    Public Shared Function ConsultarIncidenciasResueltasHorasExtra(pidEstado As Integer, pidCategoria As Integer) As DataTable

        Try
            conectado()
            cmd = New SqlCommand("consultarIncidenciasResueltasHorasExtra")
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = cnn

            cmd.Parameters.AddWithValue("@ID_ESTADO_INC", pidEstado)
            cmd.Parameters.AddWithValue("@ID_CATEGORIAS", pidCategoria)

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function

    Public Shared Function consultarIncidenciasResueltasCanceladas(pidEstado As Integer, pidCategoria As Integer) As DataTable

        Try
            conectado()
            cmd = New SqlCommand("consultarIncidenciasResueltasCanceladas")
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Connection = cnn

            'cmd.Parameters.AddWithValue("@ID_ESTADO_INC", pidEstado)
            cmd.Parameters.AddWithValue("@ID_CATEGORIAS", pidCategoria)

            If cmd.ExecuteNonQuery Then
                Dim dt As New DataTable
                Dim da As New SqlDataAdapter(cmd)
                da.Fill(dt)
                Return dt
            Else
                Return Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
            Return Nothing
        Finally
            desconectado()
        End Try
    End Function


End Class



