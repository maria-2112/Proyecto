﻿Imports DATOS
Imports Logica

Public Class frmPrincipal
    Public user As DUsuario

    Sub HabilitarPorRol(prol As Integer)

        Select Case prol
            Case 1
                'Roles a definir
            Case 2
               
            Case 3
                
        End Select
    End Sub
    Private Sub frmPrincipal_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim log As New frmLogin
        Me.Hide()
        log.ShowDialog()

    End Sub

    Private Sub btnIncidencias_Click(sender As Object, e As EventArgs) Handles btnIncidencias.Click
        Dim frmIngIncidencias As New frmIngresarIncidencia()
        Me.Hide()
        frmIngIncidencias.user = user
        frmIngIncidencias.ShowDialog()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnMantUsuarios.Click
        Dim consulta As New frmConsulta
        Me.Hide()
        consulta.user = user
        consulta.ShowDialog()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim ob As New frmMantenimientoIncidencias
        ob.user = user
        Me.Hide()
        ob.ShowDialog()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim ob As New frmConsultaManteni
        ob.user = user
        Me.Hide()
        ob.ShowDialog()

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim ob As New frmConsultaReporte
        ob.user = user
        Me.Hide()
        ob.ShowDialog()
    End Sub
End Class