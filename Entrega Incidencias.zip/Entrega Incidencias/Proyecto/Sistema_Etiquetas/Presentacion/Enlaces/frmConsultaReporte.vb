﻿Imports DATOS

Public Class frmConsultaReporte
    Public user As DUsuario

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim obj As New frmReporteIncidentes
        obj.user = user
        Me.Hide()
        obj.ShowDialog()

    End Sub

    Private Sub btnAtras_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        Dim obj As New frmPrincipal
        obj.user = user
        Me.Hide()
        obj.ShowDialog()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim obj As New frmReportResueltos
        obj.user = user
        Me.Hide()
        obj.ShowDialog()
    End Sub
End Class