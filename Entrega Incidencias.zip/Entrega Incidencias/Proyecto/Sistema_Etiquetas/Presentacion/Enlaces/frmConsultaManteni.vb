﻿Imports DATOS

Public Class frmConsultaManteni
    Public user As DUsuario

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim ob As New frmMantenimientoUsuarios
        ob.user = user
        Me.Hide()
        ob.ShowDialog()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim ob As New frmMantenimientoRoles
        ob.user = user
        Me.Hide()
        ob.ShowDialog()
    End Sub

    Private Sub btnAtras_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        Dim obj As New frmPrincipal
        Me.Hide()
        obj.ShowDialog()
    End Sub
End Class