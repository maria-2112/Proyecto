﻿Imports DATOS
Imports Logica

Public Class frmIngresarIncidencia

    Public user As DUsuario
    Private dt As DataTable
    Dim tableIncidencias As DataTable

    Private Sub frmIngresarIncidencia_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tableIncidencias = New DataTable("Cursos")
        tableIncidencias.Columns.Add("Nº Incidencia")
        tableIncidencias.Columns.Add("Usuario")
        tableIncidencias.Columns.Add("Categoría")
        tableIncidencias.Columns.Add("Fecha estimada")
        tableIncidencias.Columns.Add("Fecha asignada")
        tableIncidencias.Columns.Add("Fecha resuelta")
        tableIncidencias.Columns.Add("Estado")
        gvIncidencias.DataSource = tableIncidencias

        gvIncidencias.Columns("Nº Incidencia").Width = 40
        CargarPrioridades()
        CargarIncidencias()
    End Sub
    Sub CargarPrioridades()
        dt = AccesoCategorias.ObtenerCategorias()
        cmbPrioridad.DataSource = dt
        cmbPrioridad.ValueMember = "ID_CATEGORIAS"
        cmbPrioridad.DisplayMember = "DESCRIPION"
    End Sub


    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Dim frmMenuPrincipal As New frmPrincipal()
        Me.Hide()
        frmMenuPrincipal.user = user
        frmMenuPrincipal.ShowDialog()
    End Sub

    Private Sub btnIngresar_Click(sender As Object, e As EventArgs) Handles btnIngresar.Click
        Dim inc As New DIncidencias

        If (cmbPrioridad.SelectedIndex = -1) Then
            MessageBox.Show("Debe seleccionar la prioridad de la incidencia.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Try
                inc.CodUsuario = 1
                inc.Fecha_Creacion = DateTime.Today
                inc.IdCategorias = cmbPrioridad.SelectedItem("ID_CATEGORIAS").ToString()
                inc.Fecha_Est = GestorIncidencia.ObtenerFechaEstimada(Now(), Convert.ToInt32(cmbPrioridad.SelectedItem("ID_CATEGORIAS")))
                inc.Fecha_Asigna = GestorIncidencia.ObtenerFechaAsignada(Now(), Convert.ToInt32(cmbPrioridad.SelectedItem("ID_CATEGORIAS")))
                inc.Estado = 5
                GestorIncidencia.InsertarIncidencia(inc)
                MessageBox.Show("Se ha registrado con éxito.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
                CargarIncidencias()
            Catch ex As Exception
                MessageBox.Show("Problemas en la gestión de la información.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
    Sub CargarIncidencias()

        Try
            Dim checkBoxColumn As DataGridViewCheckBoxColumn = New DataGridViewCheckBoxColumn()
            checkBoxColumn.HeaderText = ""
            checkBoxColumn.Width = 15
            checkBoxColumn.Name = "Seleccionar"

            If gvIncidencias.Columns.GetFirstColumn(0).Name <> "Seleccionar" Then
                gvIncidencias.Columns.Insert(0, checkBoxColumn)
            End If

            gvIncidencias.Columns("Seleccionar").Width = 30
            gvIncidencias.Columns("Seleccionar").ReadOnly = False

            tableIncidencias.Rows.Clear()

            Dim lstDIncidencias As List(Of DIncidencias) = GestorIncidencia.ObtenerIncidentes()

            If IsNothing(lstDIncidencias) = False Then

                For Each inc As DIncidencias In lstDIncidencias

                    Dim user = GestorUsuario.ObtenerUsuarioCode(inc.CodUsuario)

                    tableIncidencias.Rows.Add(
                    inc.CodIncidencia,
                    (user.Nombre + " " + user.Apellido),
                    GestorCategorias.ObtenerCategoriaId(inc.IdCategorias).Descripcion,
                    inc.Fecha_Est,
                    inc.Fecha_Asigna,
                     If(inc.Fecha_Result.ToString() <> "12:00:00 a.m." And inc.Fecha_Result.ToString() <> Nothing, inc.Fecha_Result, "No resuelta"),
                   GestorCategorias.ObtenerEstadoId(inc.Estado).Descripcion)
                Next
            End If

            gvIncidencias.AllowUserToAddRows = False
            gvIncidencias.RowHeadersVisible = False

        Catch ex As Exception
            MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try
        AplicarColorFilas()
    End Sub

    Sub AplicarColorFilas()

        For Each row As DataGridViewRow In gvIncidencias.Rows
            'Dim cell As DataGridViewCheckBoxCell = TryCast(row.Cells("Estado"), DataGridViewCheckBoxCell)
            Dim inc As DIncidencias = GestorIncidencia.ObtenerIncidentesId(Convert.ToInt32(row.Cells(1).Value()))

            Select Case inc.Estado
                Case 1
                    row.DefaultCellStyle.BackColor = Color.Green
                Case 5
                    row.DefaultCellStyle.BackColor = Color.White
                Case 2
                    row.DefaultCellStyle.BackColor = Color.Yellow
                Case 3
                    row.DefaultCellStyle.BackColor = Color.Red
            End Select

            If inc.Cancelado Then
                row.DefaultCellStyle.BackColor = Color.Gray
            End If

        Next
    End Sub
    Sub VerificarCambiosControls()

        Dim incidencia As DIncidencias = GestorIncidencia.ObtenerIncidentesId(Convert.ToInt32(txtNIncidencia.Text))

        chkCancelar.Checked = incidencia.Cancelado
        VerificarHorasExtras(incidencia)
        lnkModificar.Visible = incidencia.Estado = 5 And (Not incidencia.Cancelado)
        chkHorasEstras.Checked = incidencia.Horas > 0
        txtHorasExtras.Text = incidencia.Horas
    End Sub

    Private Sub VerIncidencia_Click(sender As Object, e As EventArgs) Handles VerIncidencia.Click
        CargarIncidenciaConsultada()
    End Sub

    Sub CargarIncidenciaConsultada()
        If ValiudarSeleccionIncidencia() = 0 Or ValiudarSeleccionIncidencia() > 1 Then
            MessageBox.Show("Debe seleccionar una incidencia", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            GroupBox2.Visible = False
            Panel2.Visible = True

            Dim incidencia As DIncidencias = GestorIncidencia.ObtenerIncidentesId(Convert.ToInt32(gvIncidencias.CurrentRow.Cells.Item(1).Value.ToString()))
            Dim user = GestorUsuario.ObtenerUsuarioCode(incidencia.CodUsuario)

            txtNIncidencia.Text = incidencia.CodIncidencia
            txtUsuario.Text = (user.Nombre + " " + user.Apellido)
            cmbCategorias.Text = GestorCategorias.ObtenerCategoriaId(incidencia.IdCategorias).Descripcion
            txtFechaEstimada.Text = incidencia.Fecha_Est
            txtFechaAsignada.Text = incidencia.Fecha_Asigna
            txtFechaResulelta.Text = If(incidencia.Fecha_Result.ToString() <> "12:00:00 a.m.", incidencia.Fecha_Result, "No resuelta")
            txtEstado.Text = GestorCategorias.ObtenerEstadoId(incidencia.Estado).Descripcion
            chkCancelar.Checked = incidencia.Cancelado
            VerificarHorasExtras(incidencia)
            lnkModificar.Visible = incidencia.Estado = 5
            lnkModificar.Visible = Not incidencia.Cancelado
            GroupBox1.Visible = False
        End If
    End Sub

    Sub VerificarHorasExtras(pincidencia As DIncidencias)
        chkHorasEstras.Checked = pincidencia.Horas > 0
        txtHorasExtras.Enabled = pincidencia.Horas = 0
        txtHorasExtras.Text = pincidencia.Horas
    End Sub


    Public Function ValiudarSeleccionIncidencia() As Integer
        Dim cont As Integer = 0

        For Each row As DataGridViewRow In Me.gvIncidencias.Rows
            Dim cell As DataGridViewCheckBoxCell = TryCast(row.Cells("Seleccionar"), DataGridViewCheckBoxCell)

            If cell.Value Then
                cont += 1
            End If
        Next
        Return cont
    End Function

    Private Sub chkHorasEstras_CheckedChanged(sender As Object, e As EventArgs) Handles chkHorasEstras.CheckedChanged
        txtHorasExtras.Visible = chkHorasEstras.Checked
    End Sub

    Private Sub lnkModificar_Click(sender As Object, e As EventArgs) Handles lnkModificar.Click

        chkCancelar.Enabled = Not chkCancelar.Checked
        chkHorasEstras.Enabled = Not chkHorasEstras.Checked
        btnCancelar.Visible = True
        btnGuardar.Visible = True
        lnkModificar.Visible = False
        btnAtras.Visible = False
    End Sub

    Private Sub txtHorasExtras_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtHorasExtras.KeyPress
        If (Not IsNumeric(txtHorasExtras.Text)) Then
            txtHorasExtras.Clear()
            MessageBox.Show("Debe ingresar solo números.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtHorasExtras.Clear()
        End If
    End Sub

    Private Sub txtHorasExtras_KeyUp(sender As Object, e As KeyEventArgs) Handles txtHorasExtras.KeyUp
        If (Not IsNumeric(txtHorasExtras.Text)) Then
            txtHorasExtras.Text = 0
            MessageBox.Show("Debe ingresar solo números.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtHorasExtras.Text = 0
        End If
    End Sub

    Private Sub btnCancelar_Click(sender As Object, e As EventArgs) Handles btnCancelar.Click
        Limpiar()
        CargarIncidenciaConsultada()
    End Sub

    Sub Limpiar()
        chkCancelar.Enabled = False
        chkHorasEstras.Enabled = False
        btnCancelar.Visible = False
        btnGuardar.Visible = False
        btnAtras.Visible = True
    End Sub

    Private Sub btnAtras_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        GroupBox2.Visible = True
        Panel2.Visible = False
        GroupBox1.Visible = True
        CargarIncidencias()
    End Sub

    Private Sub btnGuardar_Click(sender As Object, e As EventArgs) Handles btnGuardar.Click

        Dim incidencia As DIncidencias = GestorIncidencia.ObtenerIncidentesId(Convert.ToInt32(gvIncidencias.CurrentRow.Cells.Item(1).Value.ToString()))

        If (MessageBox.Show("¿Está seguro que desea guardar los cambios? ", "Aviso", MessageBoxButtons.YesNo,
                             MessageBoxIcon.Question) = DialogResult.Yes) Then
            incidencia.Horas = If(IsNumeric(txtHorasExtras.Text), Convert.ToInt16(txtHorasExtras.Text), 0)
            incidencia.Cancelado = chkCancelar.Checked
            GestorIncidencia.EditarIncidencia(incidencia)
            MessageBox.Show("Se ha modificado la incidencia con éxito", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
            'CargarIncidenciaConsultada()
            VerificarCambiosControls()
            Limpiar()
        End If
    End Sub

    Private Sub btnAtender_Click(sender As Object, e As EventArgs) Handles btnAtender.Click

        If ValiudarSeleccionIncidencia() = 0 Or ValiudarSeleccionIncidencia() > 1 Then
            MessageBox.Show("Debe seleccionar una incidencia", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Dim incidencia As DIncidencias = GestorIncidencia.ObtenerIncidentesId(Convert.ToInt32(gvIncidencias.CurrentRow.Cells.Item(1).Value.ToString()))

            If incidencia.Estado <> 5 Then
                MessageBox.Show("La incidencia seleccionada ya fue atendida", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)

            ElseIf (incidencia.Cancelado) Then
                MessageBox.Show("La incidencia seleccionada ha sido cancelada", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)

            Else
                If (MessageBox.Show("¿Está seguro que desea resolver la incidencia? ", "Aviso", MessageBoxButtons.YesNo,
                 MessageBoxIcon.Question) = DialogResult.Yes) Then
                    incidencia.Fecha_Result = Now
                    incidencia.Estado = ObtenerCodigoEstadoFinal(incidencia)
                    GestorIncidencia.EditarIncidencia(incidencia)
                    MessageBox.Show("Se ha resuelto la incidencia con éxito", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    'CargarIncidencias()
                End If
            End If

            CargarIncidencias()
        End If

    End Sub
    Public Function ObtenerCodigoEstadoFinal(pincidencia As DIncidencias) As Integer

        Dim codEstado = 0

        If (pincidencia.Fecha_Result > Now()) And (pincidencia.Horas > 0) Then
            codEstado = 2

        ElseIf (pincidencia.Fecha_Result > Now()) And (pincidencia.Horas = 0) Then
            codEstado = 3

        ElseIf (pincidencia.Fecha_Result < Now()) Then
            codEstado = 1

        End If
        Return codEstado
    End Function
End Class

