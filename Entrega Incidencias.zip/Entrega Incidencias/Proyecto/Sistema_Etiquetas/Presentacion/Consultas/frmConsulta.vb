﻿
Imports DATOS

Public Class frmConsulta
    Public user As DUsuario
    Private dt As New DataTable
    Private Sub Mostrar()

        Try
            dt = AccesoConsulta.ObtenerConsulta


            If dt.Rows.Count <> 0 Then
                datalistado.DataSource = dt
                txtbuscar.Enabled = True
                cbocampo.Enabled = True
                dataFechaInicio.Enabled = True
                dataFechaFinal.Enabled = True
                inexistente.Visible = False
                cmbEstado.Enabled = True
                btnConsulta.Enabled = True
                cbmFecha.Enabled = True




            Else
                datalistado.DataSource = Nothing
                txtbuscar.Enabled = False
                cbocampo.Enabled = False
                dataFechaInicio.Enabled = False
                dataFechaFinal.Enabled = False
                inexistente.Visible = True
                cmbEstado.Enabled = False
                btnConsulta.Enabled = False
                cbmFecha.Enabled = False

            End If
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
        Buscar()


    End Sub

    Private Sub Buscar()
        Try
            Dim ds As New DataSet
            ds.Tables.Add(dt.Copy)
            Dim dv As New DataView(ds.Tables(0))


            dv.RowFilter = cbocampo.Text & " like '" & txtbuscar.Text & "%'"

            If dv.Count <> 0 Then
                inexistente.Visible = False
                datalistado.DataSource = dv


            Else
                inexistente.Visible = True
                datalistado.DataSource = Nothing
            End If

        Catch ex As Exception
            MsgBox(ex.Message)

        End Try
    End Sub
    Private Sub Buscar2()
        Try
            dt = AccesoConsulta.ObtenerConsultaFecha(Convert.ToString(dataFechaInicio.Text), Convert.ToString(dataFechaFinal.Text))
            If dt.Rows.Count <> 0 Then
                datalistado.DataSource = dt
                inexistente.Visible = False
            Else
                datalistado.DataSource = Nothing
                inexistente.Visible = True
            End If
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

    End Sub
    Private Sub Buscar3()
        Try
            dt = AccesoConsulta.ObtenerConsultaFechaAsigna(Convert.ToString(dataFechaInicio.Text), Convert.ToString(dataFechaFinal.Text))
            If dt.Rows.Count <> 0 Then
                datalistado.DataSource = dt
                inexistente.Visible = False
            Else
                datalistado.DataSource = Nothing
                inexistente.Visible = True
            End If
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

    End Sub
    Private Sub Buscar4()
        Try
            dt = AccesoConsulta.ObtenerConsultaFechaResult(Convert.ToString(dataFechaInicio.Text), Convert.ToString(dataFechaFinal.Text))
            If dt.Rows.Count <> 0 Then
                datalistado.DataSource = dt
                inexistente.Visible = False
            Else
                datalistado.DataSource = Nothing
                inexistente.Visible = True
            End If
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

    End Sub
    Private Sub Buscar5()
        Try
            dt = AccesoConsulta.ObtenerConsultaEstado(cmbEstado.Text)
            If dt.Rows.Count <> 0 Then
                datalistado.DataSource = dt
                inexistente.Visible = False
            Else
                datalistado.DataSource = Nothing
                inexistente.Visible = True
            End If
        Catch ex As Exception
            MsgBox(ex.Message)

        End Try

    End Sub

    Private Sub frmConsulta_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Mostrar()
    End Sub

    Private Sub txtbuscar_TextChanged(sender As Object, e As EventArgs) Handles txtbuscar.TextChanged
        Buscar()

    End Sub

    Private Sub Limpiar()
        txtbuscar.Text = ""
        cbmFecha.Text = "Seleccione..."
        cmbEstado.Text = "Seleccione..."
        dataFechaInicio.Text = ""
        dataFechaFinal.Text = ""


    End Sub


    Private Sub btnConsulta_Click(sender As Object, e As EventArgs) Handles btnConsulta.Click
        If txtbuscar.Text = "" And cbmFecha.SelectedItem = "Seleccione...." Then
            Buscar5()
            Limpiar()
        End If


    End Sub

    Private Sub RefrescarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefrescarToolStripMenuItem.Click
        Mostrar()
        Limpiar()

    End Sub

    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click
        Application.Exit()

    End Sub

    Private Sub btnAtras_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        Dim obj As New frmPrincipal
        obj.user = user
        Me.Hide()
        obj.ShowDialog()

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If txtbuscar.Text = "" Then
            If cbmFecha.SelectedItem = "Fecha de Creacion" Then
                Buscar2()
                Limpiar()

            Else
                If cbmFecha.SelectedItem = "Fecha Asignada" Then
                    Buscar3()
                    Limpiar()

                Else

                    If cbmFecha.SelectedItem = "Fecha Finalización" Then
                        Buscar4()
                        Limpiar()
                    Else
                    End If
                End If
            End If

        End If


    End Sub
End Class