﻿Imports DATOS
Imports System.Data.SqlClient

Public Class frmReporteIncidentes
    Public user As DUsuario

    Private Function ObtenerAnterior() As String()

        Try
            Using cnn As New SqlConnection(Configuracion.CadenaConexion)

                Dim cmd As SqlCommand = cnn.CreateCommand()
                cmd.CommandText = "select count(ID_INCIDENCIAS ) as Total from INCIDENCIAS where FECHA_CREACION NOT BETWEEN '01/12/2016' and '30/12/2016'and ID_ESTADO_INC=5;"


                cnn.Open()

                Dim dr As SqlDataReader =
                    cmd.ExecuteReader(CommandBehavior.CloseConnection)

                Dim values(2) As String
                Dim index As Integer = 0

                While dr.Read()
                    values(index) = Convert.ToString(dr.Item("Total"))
                    index += 1
                    If (index > 2) Then Exit While
                End While

                dr.Close()

                Return values

            End Using

        Catch
            Throw

        End Try

    End Function

    Private Function ObtenerAbiertas() As String()

        Try
            Using cnn As New SqlConnection(Configuracion.CadenaConexion)

                Dim cmd As SqlCommand = cnn.CreateCommand()
                cmd.CommandText = "select count(ID_INCIDENCIAS ) as Total from INCIDENCIAS where FECHA_CREACION  BETWEEN '01/12/2016' and '30/12/2016';"


                cnn.Open()

                Dim dr As SqlDataReader =
                    cmd.ExecuteReader(CommandBehavior.CloseConnection)

                Dim values(2) As String
                Dim index As Integer = 0

                While dr.Read()
                    values(index) = Convert.ToString(dr.Item("Total"))
                    index += 1
                    If (index > 2) Then Exit While
                End While

                dr.Close()

                Return values

            End Using

        Catch
            Throw

        End Try

    End Function
    Private Function ObtenerResueltas() As String()

        Try
            Using cnn As New SqlConnection(Configuracion.CadenaConexion)

                Dim cmd As SqlCommand = cnn.CreateCommand()
                cmd.CommandText = "select count(ID_INCIDENCIAS ) as Total from INCIDENCIAS where FECHA_RESULT  BETWEEN '01/12/2016' and '30/12/2016';"


                cnn.Open()

                Dim dr As SqlDataReader =
                    cmd.ExecuteReader(CommandBehavior.CloseConnection)

                Dim values(2) As String
                Dim index As Integer = 0

                While dr.Read()
                    values(index) = Convert.ToString(dr.Item("Total"))
                    index += 1
                    If (index > 2) Then Exit While
                End While

                dr.Close()

                Return values

            End Using

        Catch
            Throw

        End Try

    End Function
    Private Function ObtenerPendientes() As String()

        Try
            Using cnn As New SqlConnection(Configuracion.CadenaConexion)

                Dim cmd As SqlCommand = cnn.CreateCommand()
                cmd.CommandText = "select count(ID_INCIDENCIAS ) as Total from INCIDENCIAS where FECHA_RESULT NOT BETWEEN '01/12/2016' and '30/12/2016';"


                cnn.Open()

                Dim dr As SqlDataReader =
                    cmd.ExecuteReader(CommandBehavior.CloseConnection)

                Dim values(2) As String
                Dim index As Integer = 0

                While dr.Read()
                    values(index) = Convert.ToString(dr.Item("Total"))
                    index += 1
                    If (index > 2) Then Exit While
                End While

                dr.Close()

                Return values

            End Using

        Catch
            Throw

        End Try

    End Function
    Private Sub leerAnterior()
        Try
            Dim valores As String() = ObtenerAnterior()

            If (valores Is Nothing) Then
                TextBox1.Clear()
                Return
            End If

            TextBox1.Text = valores(0)

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Private Sub leerAbiertas()
        Try

            Dim valores As String() = ObtenerAbiertas()

            If (valores Is Nothing) Then

                TextBox2.Clear()
                Return
            End If

            TextBox2.Text = valores(0)

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try


    End Sub
    Private Sub leerResueltas()
        Try

            Dim valores As String() = ObtenerAnterior()

            If (valores Is Nothing) Then

                TextBox3.Clear()
                Return
            End If

            TextBox3.Text = valores(0)

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try


    End Sub
    Private Sub leerPendientes()
        Try

            Dim valores As String() = ObtenerPendientes()

            If (valores Is Nothing) Then
                TextBox4.Clear()
                Return
            End If

            TextBox4.Text = valores(0)

        Catch ex As Exception

            MessageBox.Show(ex.Message)

        End Try


    End Sub

    Private Sub frmReporteIncidentes_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call leerAnterior()
        Call leerAbiertas()
        Call leerResueltas()
        Call leerPendientes()
    End Sub

    Private Sub btnAtras_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        Dim obj As New frmPrincipal
        obj.user = user
        Me.Hide()
        obj.ShowDialog()
    End Sub
End Class