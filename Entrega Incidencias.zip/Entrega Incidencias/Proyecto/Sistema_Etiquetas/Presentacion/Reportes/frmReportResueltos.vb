﻿Imports DATOS
Imports Logica

Public Class frmReportResueltos

    Dim tableResults As DataTable
    Public user As DUsuario

    Private Sub frmReportResueltos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tableResults = New DataTable("Resultados")
        tableResults.Columns.Add("Resultados por mes")
        tableResults.Columns.Add("Emergencia")
        tableResults.Columns.Add("Alta")
        tableResults.Columns.Add("Media")
        tableResults.Columns.Add("Baja")
        gvResultados.DataSource = tableResults
        CargarIncidenciasResuletas()
    End Sub

    Sub CargarIncidenciasResuletas()

        Try
            tableResults.Rows.Clear()

            'Resueltos a tiempo(Si porroga)
            Dim emerAtiem As Integer = GestorIncidencia.ConsultarIncidenciasResueltas(1, 1) 'Emergencia
            Dim altaAtiem As Integer = GestorIncidencia.ConsultarIncidenciasResueltas(1, 2) 'Alta
            Dim mediaAtiem As Integer = GestorIncidencia.ConsultarIncidenciasResueltas(1, 3) 'Media
            Dim bajaAtiem As Integer = GestorIncidencia.ConsultarIncidenciasResueltas(1, 4) 'Baja
            tableResults.Rows.Add("Resueltos a Tiempo (sin prórroga)", emerAtiem, altaAtiem, mediaAtiem, bajaAtiem)

            'Resueltos a tiempo(Con porroga)
            Dim emerATiemPorr As Integer = GestorIncidencia.ConsultarIncidenciasResueltasHorasExtra(2, 1) 'Emergencia
            Dim altaATiemPorr As Integer = GestorIncidencia.ConsultarIncidenciasResueltasHorasExtra(2, 2) 'Alta
            Dim mediATiemPorr As Integer = GestorIncidencia.ConsultarIncidenciasResueltasHorasExtra(2, 3) 'Media
            Dim bajaATiemPorr As Integer = GestorIncidencia.ConsultarIncidenciasResueltasHorasExtra(2, 4) 'Baja
            tableResults.Rows.Add("Resueltos a Tiempo (sin prórroga)", emerATiemPorr, altaATiemPorr, mediATiemPorr, bajaATiemPorr)

            'Resueltos no a tiempo(Si porroga)
            Dim emerANotiem As Integer = GestorIncidencia.ConsultarIncidenciasResueltas(3, 1) 'Emergencia
            Dim altaANotiem As Integer = GestorIncidencia.ConsultarIncidenciasResueltas(3, 2) 'Alta
            Dim mediaANotiem As Integer = GestorIncidencia.ConsultarIncidenciasResueltas(3, 3) 'Media
            Dim bajaANotiem As Integer = GestorIncidencia.ConsultarIncidenciasResueltas(3, 4) 'Baja
            tableResults.Rows.Add("Resueltos no a tiempo ", emerANotiem, altaANotiem, mediaANotiem, bajaANotiem)

            'Cancelados
            Dim emerCancelados As Integer = GestorIncidencia.consultarIncidenciasResueltasCanceladas(3, 1) 'Emergencia
            Dim altaCancelados As Integer = GestorIncidencia.consultarIncidenciasResueltasCanceladas(3, 2) 'Alta
            Dim mediCancelados As Integer = GestorIncidencia.consultarIncidenciasResueltasCanceladas(3, 3) 'Media
            Dim bajaCancelados As Integer = GestorIncidencia.consultarIncidenciasResueltasCanceladas(3, 4) 'Baja
            tableResults.Rows.Add("Canceladas", emerCancelados, altaCancelados, mediCancelados, bajaCancelados)

            gvResultados.AllowUserToAddRows = False
            gvResultados.RowHeadersVisible = False

        Catch ex As Exception
            MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnAtras_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        Dim obj As New frmPrincipal
        obj.user = user
        Me.Hide()
        obj.ShowDialog()
    End Sub
End Class