﻿Imports DATOS
Imports System.IO
Imports System.Net
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports Logica

Public Class frmMantenimientoIncidencias
    Public user As DUsuario

    Private Sub frmMantenimientoIncidencias_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub


    Private Sub btnGuardar_Click(sender As Object, e As EventArgs) Handles btnGuardar.Click
        GestorIncidencia.AlmacenarIncidencias()
    End Sub

    Private Sub btnAtras_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        Dim obj As New frmPrincipal
        obj.user = user
        Me.Hide()
        obj.ShowDialog()
    End Sub
End Class