﻿Imports Logica
Imports DATOS
Public Class frmMantenimientoRoles
    Public user As DUsuario

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Me.ValidateChildren = True And txtDescripcion.Text <> "" Then
            Try
                Dim obj As New DRoles
                obj.Descripcion = txtDescripcion.Text
                GestorRol.InsertarRoles(obj)
                MessageBox.Show("Curso registrado correctamente", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Limpiar()

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        Else
            MessageBox.Show("Falta ingresar algunos datos", "Guardando registros", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If


    End Sub

    Private Sub Limpiar()
        Throw New NotImplementedException
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim result As DialogResult

        result = MessageBox.Show("Realmente desea eliminar los rol seleccionados?", "Eliminando registros", MessageBoxButtons.OKCancel, MessageBoxIcon.Question)

        If result = DialogResult.OK Then
            Try
                Dim obj As New DRoles
                obj.IdRol = txtNivel.Text
                AccesoRoles.EliminarRole(obj)
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    Private Sub btnAtras_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        Dim obj As New frmPrincipal
        obj.user = user
        Me.Hide()
        obj.ShowDialog()
    End Sub
End Class