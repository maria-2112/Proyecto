﻿Imports DATOS

Public Class MapperIncidencia
    Public Shared Function ObtenerIncidentes(ptable As DataTable) As List(Of DIncidencias)

        Dim listaIncidencias As New List(Of DIncidencias)

        For Each row As DataRow In ptable.Rows
            Dim inc As New DIncidencias
            inc.CodIncidencia = Convert.ToInt32(row("ID_INCIDENCIAS").ToString())
            inc.CodUsuario = Convert.ToInt32(row("ID_USUARIO").ToString())
            inc.Fecha_Creacion = Convert.ToDateTime(row("FECHA_CREACION").ToString())
            inc.IdCategorias = Convert.ToInt32(row("ID_CATEGORIAS").ToString())
            inc.Fecha_Est = Convert.ToDateTime(row("FECHA_EST").ToString())
            inc.Fecha_Asigna = Convert.ToDateTime(row("FECHA_ASIGNA").ToString())
            inc.Fecha_Result = If(row("FECHA_RESULT").ToString() <> Nothing, Convert.ToDateTime(row("FECHA_RESULT").ToString()), Nothing)
            inc.Estado = Convert.ToInt32(row("ID_ESTADO_INC").ToString())
            inc.Horas = Convert.ToInt32(row("HORAS").ToString())
            inc.Cancelado = Convert.ToBoolean(row("CANCELACION").ToString())
            listaIncidencias.Add(inc)
        Next

        Return listaIncidencias
    End Function

    Public Shared Function ObtenerIncidente(ptable As DataTable) As DIncidencias
        Dim row As DataRow = ptable.Rows(0)
        Dim inc As New DIncidencias
        inc.CodIncidencia = Convert.ToInt32(row("ID_INCIDENCIAS").ToString())
        inc.CodUsuario = Convert.ToInt32(row("ID_USUARIO").ToString())
        inc.Fecha_Creacion = Convert.ToDateTime(row("FECHA_CREACION").ToString())
        inc.IdCategorias = Convert.ToInt32(row("ID_CATEGORIAS").ToString())
        inc.Fecha_Est = Convert.ToDateTime(row("FECHA_EST").ToString())
        inc.Fecha_Asigna = Convert.ToDateTime(row("FECHA_ASIGNA").ToString())
        inc.Fecha_Result = If(row("FECHA_RESULT").ToString() <> Nothing, Convert.ToDateTime(row("FECHA_RESULT").ToString()), Nothing)
        inc.Estado = Convert.ToInt32(row("ID_ESTADO_INC").ToString())
        inc.Horas = Convert.ToInt32(row("HORAS").ToString())
        inc.Cancelado = Convert.ToBoolean(row("CANCELACION").ToString())
        Return inc
    End Function

    Public Shared Function ObtenerCantidad(ptable As DataTable) As Int64
        Dim row As DataRow = ptable.Rows(0)
        Dim inc As Integer = 0
        inc = Convert.ToInt32(row("CANTIDAD").ToString())
        Return inc
    End Function
End Class
