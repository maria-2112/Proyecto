﻿Imports DATOS

Public Class MapperEstado
    Public Shared Function ObtenerEstados(ptable As DataTable) As List(Of DEstado)

        Dim listaCategorias As New List(Of DEstado)

        For Each row As DataRow In ptable.Rows
            Dim est As New DEstado
            est.IdEstado = Convert.ToInt32(row("ID_ESTADO_INC").ToString())
            est.Descripcion = row("DESCRIPION").ToString()
            listaCategorias.Add(est)
        Next

        Return listaCategorias
    End Function

    Public Shared Function ObtenerEstado(ptable As DataTable) As DEstado
        Dim row As DataRow = ptable.Rows(0)
        Dim cat As New DEstado
        cat.IdEstado = Convert.ToInt32(row("ID_ESTADO_INC").ToString())
        cat.Descripcion = row("DESCRIPION").ToString()
        Return cat
    End Function
End Class
