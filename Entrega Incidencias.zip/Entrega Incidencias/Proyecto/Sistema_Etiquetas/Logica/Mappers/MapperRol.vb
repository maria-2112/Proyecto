﻿Imports DATOS

Public Class MapperRol
    Public Shared Function ObtenerRoles(ptable As DataTable) As List(Of DRoles)

        Dim listaRoles As New List(Of DRoles)

        For Each row As DataRow In ptable.Rows
            Dim rol As New DRoles
            rol.IdRol = Convert.ToInt32(row("ID_ROLES").ToString())
            rol.Descripcion = row("DESCRIPION").ToString()
            listaRoles.Add(rol)
        Next
        Return listaRoles
    End Function

    Public Shared Function ObtenerRol(ptable As DataTable) As DRoles
        Dim row As DataRow = ptable.Rows(0)
        Dim rol As New DRoles
        rol.IdRol = Convert.ToInt32(row("ID_ROLES").ToString())
        rol.Descripcion = row("DESCRIPION").ToString()
        Return rol
    End Function
End Class
