﻿Imports DATOS

Public Class MapperCategoria
    Public Shared Function ObtenerCategorias(ptable As DataTable) As List(Of DCategorias)

        Dim listaCategorias As New List(Of DCategorias)

        For Each row As DataRow In ptable.Rows
            Dim cat As New DCategorias
            cat.IdCategoria = Convert.ToInt32(row("ID_CATEGORIAS").ToString())
            cat.Descripcion = row("DESCRIPION").ToString()
            cat.Horas = Convert.ToInt32(row("HORAS").ToString())
            listaCategorias.Add(cat)
        Next

        Return listaCategorias
    End Function

    Public Shared Function ObtenerCategoria(ptable As DataTable) As DCategorias
        Dim row As DataRow = ptable.Rows(0)
        Dim cat As New DCategorias
        cat.IdCategoria = Convert.ToInt32(row("ID_CATEGORIAS").ToString())
        cat.Descripcion = row("DESCRIPION").ToString()
        cat.Horas = Convert.ToInt32(row("HORAS").ToString())
        Return cat
    End Function
End Class
