﻿Imports DATOS

Public Class MapperUsuario
    Public Shared Function ObtenerUsuarios(ptable As DataTable) As List(Of DUsuario)

        Dim listaUsuario As New List(Of DUsuario)

        For Each row As DataRow In ptable.Rows
            Dim user As New DUsuario
            user.CodUsuario = Convert.ToInt32(row("ID_USUARIO").ToString())
            user.Nombre = row("NOMBRE").ToString()
            user.Apellido = row("APELLIDOS").ToString()
            user.Direccion = row("DIRECCION").ToString()
            user.Telefono = row("TELEFONO").ToString()
            user.Fecha_Nac = Convert.ToDateTime(row("FECHA_NAC").ToString())
            user.Correo = row("CORREO").ToString()
            user.Usuario = row("USUARIO").ToString()
            user.Pass = row("PASS").ToString()
            user.IdRol = Convert.ToInt32(row("ID_ROLES").ToString())
            listaUsuario.Add(user)
        Next

        Return listaUsuario
    End Function

    Public Shared Function ObtenerUsuario(ptable As DataTable) As DUsuario
        Dim user As New DUsuario

        If ptable.Rows.Count > 0 Then

            Dim row As DataRow = ptable.Rows(0)
            user.CodUsuario = Convert.ToInt32(row("ID_USUARIO").ToString())
            user.Nombre = row("NOMBRE").ToString()
            user.Apellido = row("APELLIDOS").ToString()
            user.Direccion = row("DIRECCION").ToString()
            user.Cedula = row("CEDULA").ToString()
            user.Telefono = row("TELEFONO").ToString()
            user.Fecha_Nac = Convert.ToDateTime(row("FECHA_NAC").ToString())
            user.Correo = row("CORREO").ToString()
            user.Usuario = row("USUARIO").ToString()
            user.Pass = row("PASS").ToString()
            user.IdRol = Convert.ToInt32(row("ID_ROLES").ToString())
        End If

        Return user
    End Function
End Class
