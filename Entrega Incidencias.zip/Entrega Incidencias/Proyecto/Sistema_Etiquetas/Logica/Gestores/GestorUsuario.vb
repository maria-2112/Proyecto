﻿Imports DATOS

Public Class GestorUsuario

    Public Shared Sub InsertarUsuario(pusuario As DUsuario)
        Try
            AccesoUsuario.InsertarUsuario(pusuario)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Shared Sub EditarUsuario(pusuario As DUsuario)
        Try
            AccesoUsuario.EditarUsuario(pusuario)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Shared Function ObtenerUsuario(pusuario As DUsuario) As DUsuario
        Try
            Return MapperUsuario.ObtenerUsuario(AccesoUsuario.ObtenerUsuario(pusuario))
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Shared Function ObtenerUsuarioCode(puserCode As Integer) As DUsuario
        Try
            Return MapperUsuario.ObtenerUsuario(AccesoUsuario.ObtenerUsuarioCodUsuario(puserCode))
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Shared Function ValidarCampos(psuario As String, ppass As String) As Boolean
        Try
            Return psuario <> String.Empty And ppass <> String.Empty
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Sub CargarIncidenciasBD()



    End Sub
End Class
