﻿Imports DATOS

Public Class GestorCategorias
    Public Shared Function ObtenerCategorias() As List(Of DCategorias)
        Try
            Return MapperCategoria.ObtenerCategorias(AccesoCategorias.ObtenerCategorias())
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Shared Function ObtenerCategoriaId(pid As Integer) As DCategorias
        Try
            Return MapperCategoria.ObtenerCategoria(AccesoCategorias.ObtenerCategoriaId(pid))
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Shared Function ObtenerEstadoId(pid As Integer) As DEstado
        Try
            Return MapperEstado.ObtenerEstado(AccesoCategorias.ObtenerEstadoId(pid))
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Shared Function ObtenerEstados() As List(Of DEstado)
        Try
            Return MapperEstado.ObtenerEstados(AccesoCategorias.ObtenerEstados())
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
