﻿Imports System.IO
Imports System.Net
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports DATOS
Imports System.Windows.Forms
Imports System.Globalization

Public Class GestorIncidencia

    Private Shared _horaInicio As Integer = 7
    Private Shared _horaFinal As Integer = 4

    Public Shared Sub InsertarIncidencia(pDIncidencias As DIncidencias)
        AccesoIncidente.InsertarIncidencia(pDIncidencias)
    End Sub

    Public Shared Sub EditarIncidencia(pDIncidencias As DIncidencias)
        Try
            AccesoIncidente.EditarIncidencia(pDIncidencias)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Shared Sub CancelarIncidencia(pidIncidente As Integer)
        Try
            AccesoIncidente.CancelarIncidencia(pidIncidente)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Shared Function ObtenerIncidentes() As List(Of DIncidencias)
        Try
            Return MapperIncidencia.ObtenerIncidentes(AccesoIncidente.ObtenerIncidentes())
        Catch ex As Exception
            Throw ex
        End Try
    End Function


    Public Shared Function ObtenerIncidentesId(pidIncidente As Integer) As DIncidencias
        Try
            Return MapperIncidencia.ObtenerIncidente(AccesoIncidente.ObtenerIncidentesId(pidIncidente))
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Shared Function ConsultarIncidenciasResueltas(pidEstado As Integer, pidCat As Integer) As Integer
        Try
            Return MapperIncidencia.ObtenerCantidad(AccesoConsulta.ConsultarIncidenciasResueltas(pidEstado, pidCat))
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Shared Function ConsultarIncidenciasResueltasHorasExtra(pidEstado As Integer, pidCat As Integer) As Integer
        Try
            Return MapperIncidencia.ObtenerCantidad(AccesoConsulta.ConsultarIncidenciasResueltasHorasExtra(pidEstado, pidCat))
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Shared Function consultarIncidenciasResueltasCanceladas(pidEstado As Integer, pidCat As Integer) As Integer
        Try
            Return MapperIncidencia.ObtenerCantidad(AccesoConsulta.consultarIncidenciasResueltasCanceladas(pidEstado, pidCat))
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Shared Function ObtenerIncidentesUsuario(pidusuario As Integer) As DIncidencias
        Try
            Return MapperIncidencia.ObtenerIncidente(AccesoIncidente.ObtenerIncidentesUsuario(pidusuario))
        Catch ex As Exception
            Throw ex
        End Try
    End Function



    Shared Sub AlmacenarIncidencias()

        Dim reader As StreamReader = New StreamReader(My.Application.Info.DirectoryPath + "\Incidencias.json")

            Dim content As String = reader.ReadToEnd()
            Dim list As List(Of DIncidencias) = JsonConvert.DeserializeObject(Of List(Of DIncidencias))(content)

        For i = 0 To 12
            Dim incidencia As DIncidencias = list(i)
            incidencia.CodUsuario = MapperUsuario.ObtenerUsuario(AccesoUsuario.ObtenerUsuarioCedula(incidencia.Cedula)).CodUsuario
            InsertarIncidencia(incidencia)
        Next

        MsgBox("Las incidencias han sido cargadas con éxito.")
    End Sub


    Public Shared Function ObtenerConsultaIncidencias() As DataTable
        Try
            Return AccesoIncidente.ObtenerConsultaIncidencias()
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Shared Function ValidarInfoRegistro(pcmbPrioridad As Integer,
                                              pfechaEst As MaskedTextBox,
                                              pfechaAsig As MaskedTextBox,
                                              pfechaRes As MaskedTextBox) As Boolean
        Try
            Return IsDate(pfechaEst.Text) And IsDate(pfechaAsig.Text) And IsDate(pfechaRes.Text) And pcmbPrioridad <> -1
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Shared Function ObtenerFechaEstimada(pfechaActual As DateTime, pidPrioridad As Integer) As DateTime

        Dim fechaActual As DateTime = pfechaActual

        Dim horas As Integer = GestorCategorias.ObtenerCategoriaId(pidPrioridad).Horas

        Select Case pidPrioridad
            Case 1
                fechaActual = DateAdd("h", 4, fechaActual)
                fechaActual = DateAdd("n", 30, fechaActual)
            Case 2
                fechaActual = DateAdd("h", 26, fechaActual)
            Case 3
                fechaActual = DateAdd("d", 4, fechaActual)
                fechaActual = If(pfechaActual.DayOfWeek = DayOfWeek.Friday, DateAdd("d", 2, fechaActual), fechaActual)
                fechaActual = If(pfechaActual.DayOfWeek = DayOfWeek.Saturday, DateAdd("d", 1, fechaActual), fechaActual)

            Case 4
                fechaActual = DateAdd("d", 12, fechaActual)
                fechaActual = If(pfechaActual.DayOfWeek = DayOfWeek.Friday, DateAdd("d", 2, fechaActual), fechaActual)
                fechaActual = If(pfechaActual.DayOfWeek = DayOfWeek.Saturday, DateAdd("d", 1, fechaActual), fechaActual)

        End Select

        Return fechaActual
    End Function

    Public Shared Function ObtenerFechaAsignada(pfechaActual As DateTime, pidPrioridad As Integer) As DateTime

        Dim fechaActual As DateTime = pfechaActual

        Dim horas As Integer = GestorCategorias.ObtenerCategoriaId(pidPrioridad).Horas

        Select Case pidPrioridad
            Case 1
                fechaActual = DateAdd("n", 30, fechaActual)
            Case 2
                fechaActual = DateAdd("h", 2, fechaActual)
            Case 3
                fechaActual = DateAdd("h", 8, fechaActual)

                If fechaActual.Hour >= _horaFinal And fechaActual.ToString("tt", CultureInfo.InvariantCulture) = "PM" Then
                    fechaActual = DateAdd("h", 17, pfechaActual)
                    fechaActual = DateAdd("h", 8, fechaActual)
                End If

            Case 4
                fechaActual = DateAdd("d", 2, fechaActual)

        End Select

        Return fechaActual
    End Function


End Class
