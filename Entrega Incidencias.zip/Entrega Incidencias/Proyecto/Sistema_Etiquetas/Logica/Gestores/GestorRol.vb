﻿Imports DATOS

Public Class GestorRol
    Public Shared Function ObtenerRoles() As List(Of DRoles)
        Try
            Return MapperRol.ObtenerRoles(AccesoRoles.ObtenerRoles())
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    Public Shared Function ObtenerRol(pid As Integer) As DRoles
        Try
            Return MapperRol.ObtenerRol(AccesoRoles.ObtenerRolId(pid))
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Shared Sub InsertarRoles(pDrole As DRoles)
        Try
            AccesoRoles.InsertarRol(pDrole)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
End Class
