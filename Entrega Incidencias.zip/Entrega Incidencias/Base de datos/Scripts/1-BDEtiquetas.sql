CREATE DATABASE DBEtiquetas
GO
-- ============================================================================================
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

DECLARE @DROP_CONSTRAINTS NVARCHAR(MAX) = N'';

SELECT @DROP_CONSTRAINTS += N'ALTER TABLE [dbo].' + OBJECT_NAME(PARENT_OBJECT_ID) + ' DROP CONSTRAINT ' + OBJECT_NAME(OBJECT_ID) + '; ' 
	FROM SYS.OBJECTS
	WHERE OBJECT_NAME(OBJECT_ID
	) like '%FK%' and TYPE_DESC LIKE '%CONSTRAINT' AND 
		(		
		  OBJECT_NAME(PARENT_OBJECT_ID) = 'INCIDENCIAS'OR
	      OBJECT_NAME(PARENT_OBJECT_ID) = 'USUARIO'OR
	      OBJECT_NAME(PARENT_OBJECT_ID) = 'ROLES'OR
		  OBJECT_NAME(PARENT_OBJECT_ID) = 'CATEGORIAS_PRIORIDADES' OR
		  OBJECT_NAME(PARENT_OBJECT_ID) = 'ESTADO_INCIDENCIA'
		);

print 'Eliminando posibles relaciones entre tablas del SCHEMA [dbo]'; 
EXECUTE (@DROP_CONSTRAINTS); 
-- ============================================================================================
-- Limpiar la variable
SET @DROP_CONSTRAINTS = '';

SELECT @DROP_CONSTRAINTS += N'ALTER TABLE [dbo].' + OBJECT_NAME(PARENT_OBJECT_ID) + ' DROP CONSTRAINT ' + OBJECT_NAME(OBJECT_ID) + '; ' 
	FROM SYS.OBJECTS
	WHERE TYPE_DESC LIKE '%CONSTRAINT' AND 
		(	
		  OBJECT_NAME(PARENT_OBJECT_ID) = 'INCIDENCIAS'OR
	      OBJECT_NAME(PARENT_OBJECT_ID) = 'USUARIO'OR
	      OBJECT_NAME(PARENT_OBJECT_ID) = 'ROLES'OR
		  OBJECT_NAME(PARENT_OBJECT_ID) = 'CATEGORIAS_PRIORIDADES'  OR
		  OBJECT_NAME(PARENT_OBJECT_ID) = 'ESTADO_INCIDENCIA'
		);

print 'Eliminando posibles CONSTRAINTs del SCHEMA [dbo]'; 
EXECUTE (@DROP_CONSTRAINTS);    
GO


-- ============================================================================================
-- Tabla ESTADO_INCIDENCIA
-- ============================================================================================
print 'Creando TABLE [USUARIO] del SCHEMA [dbo.ESTADO_INCIDENCIA]'; 

IF OBJECT_ID (N'[dbo].[ESTADO_INCIDENCIA]', N'U') IS NOT NULL
  BEGIN   
	DROP TABLE [dbo].ESTADO_INCIDENCIA;
  END
GO

CREATE TABLE [dbo].ESTADO_INCIDENCIA(
 ID_ESTADO_INC INT IDENTITY(1,1) NOT NULL,
 DESCRIPION    VARCHAR(50) NOT NULL,

 CONSTRAINT [PK_ID_ESTADO_INC] PRIMARY KEY CLUSTERED (ID_ESTADO_INC ASC)
 WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


-- ============================================================================================
-- Tabla CATEGORIAS_PRIORIDADES
-- ============================================================================================
print 'Creando TABLE [CATEGORIAS_PRIORIDADES] del SCHEMA [dbo]'; 

IF OBJECT_ID (N'[dbo].[CATEGORIAS_PRIORIDADES]', N'U') IS NOT NULL
  BEGIN   
	DROP TABLE [dbo].CATEGORIAS_PRIORIDADES;
  END
GO

CREATE TABLE [dbo].CATEGORIAS_PRIORIDADES(
 ID_CATEGORIAS int IDENTITY(1,1) NOT NULL,
 DESCRIPION     VARCHAR(50) NOT NULL,
 HORAS INT NOT NULL,

 CONSTRAINT [PK_ID_CATEGORIAS] PRIMARY KEY CLUSTERED (ID_CATEGORIAS ASC)
 WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- ============================================================================================
-- Tabla ROLES
-- ============================================================================================
print 'Creando TABLE [ROLES] del SCHEMA [dbo]'; 

IF OBJECT_ID (N'[dbo].[ROLES]', N'U') IS NOT NULL
  BEGIN   
	DROP TABLE [dbo].ROLES;
  END
GO

CREATE TABLE [dbo].ROLES(
 ID_ROLES   INT IDENTITY(1,1) NOT NULL,
 DESCRIPION VARCHAR(50) NOT NULL,

 CONSTRAINT [PK_ID_ROLES] PRIMARY KEY CLUSTERED (ID_ROLES ASC)
 WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- ============================================================================================
-- Tabla USUARIO
-- ============================================================================================
print 'Creando TABLE [USUARIO] del SCHEMA [dbo]'; 

IF OBJECT_ID (N'[dbo].[USUARIO]', N'U') IS NOT NULL
  BEGIN   
	DROP TABLE [dbo].USUARIO;
  END
GO

CREATE TABLE [dbo].USUARIO(
 ID_USUARIO int IDENTITY(1,1) NOT NULL,
 NOMBRE     VARCHAR(50) NOT NULL,
 APELLIDOS  VARCHAR(50) NOT NULL,
 DIRECCION NVARCHAR(100) NOT NULL,
 TELEFONO VARCHAR(10)NOT NULL,
 CEDULA VARCHAR(9)NOT NULL,
 FECHA_NAC Datetime NOT NULL,
 CORREO  VARCHAR(50) NOT NULL,
 USUARIO    VARCHAR(50) NOT NULL,
 PASS       VARCHAR(50) NOT NULL,
 ID_ROLES     int NOT NULL,

 CONSTRAINT FK_ID_ROLES FOREIGN KEY( ID_ROLES)
 REFERENCES [dbo].[ROLES]( ID_ROLES),

 CONSTRAINT [PK_ID_USUARIO] PRIMARY KEY CLUSTERED (ID_USUARIO ASC)
 WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


-- ============================================================================================
-- Tabla INCIDENCIAS
-- ============================================================================================
print 'Creando TABLE [INCIDENCIAS] del SCHEMA [dbo]'; 

IF OBJECT_ID (N'[dbo].[INCIDENCIAS]', N'U') IS NOT NULL
  BEGIN   
	DROP TABLE [dbo].INCIDENCIAS;
  END
GO

CREATE TABLE [dbo].INCIDENCIAS(
ID_INCIDENCIAS INT IDENTITY(1,1) NOT NULL,
ID_USUARIO     INT NOT NULL,
FECHA_CREACION VARCHAR(50) NOT NULL,
ID_CATEGORIAS  INT NOT NULL,
FECHA_EST      VARCHAR(50) NOT NULL,
FECHA_ASIGNA   VARCHAR(50) NOT NULL,
FECHA_RESULT   VARCHAR(50) NULL,
HORAS          INT NULL,
ID_ESTADO_INC  INT NULL,
CANCELACION    BIT NULL,

 CONSTRAINT FK_ID_ESTADO_INC FOREIGN KEY(ID_ESTADO_INC)
 REFERENCES [dbo].ESTADO_INCIDENCIA(ID_ESTADO_INC),

 CONSTRAINT FK_ID_USUARIO FOREIGN KEY(ID_USUARIO)
 REFERENCES [dbo].[USUARIO](ID_USUARIO),

 CONSTRAINT FK_ID_CATEGORIAS FOREIGN KEY(ID_CATEGORIAS)
 REFERENCES [dbo].[CATEGORIAS_PRIORIDADES](ID_CATEGORIAS),

 CONSTRAINT [PK_ID_INCIDENCIAS] PRIMARY KEY CLUSTERED (ID_INCIDENCIAS ASC)
 WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

-- ============================================================================================
--
-- ============================================================================================